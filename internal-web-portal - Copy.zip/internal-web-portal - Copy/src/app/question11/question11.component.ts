import { Component } from '@angular/core';

@Component({
  selector: 'app-question11',
  standalone: true,
  imports: [],
  templateUrl: './question11.component.html',
  styleUrl: './question11.component.css'
})
export class Question11Component {

}
