import { CustomTitleCasePipePipe } from './custom-title-case-pipe.pipe';

describe('CustomTitleCasePipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomTitleCasePipePipe();
    expect(pipe).toBeTruthy();
  });
});
