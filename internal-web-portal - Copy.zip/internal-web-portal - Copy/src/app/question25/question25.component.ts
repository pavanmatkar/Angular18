import { Component } from '@angular/core';

@Component({
  selector: 'app-question25',
  standalone: true,
  imports: [],
  templateUrl: './question25.component.html',
  styleUrl: './question25.component.css'
})
export class Question25Component {

}
